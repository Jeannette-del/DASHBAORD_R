library(shiny)
library(dplyr)
library(ggplot2)
library(readxl)
library(ggforce) # for 'geom_arc_bar'
library(rCharts)
library(shinythemes)

# Define UI for application that draws a histogram
PERFORMANCE <- read_excel("Data/ANALSE.xlsx")
ui <- fluidPage(theme = shinytheme("united"),
  div(tags$img( src = "PHOTO.jfif",width = 1150, height = 140)),
                #headerPanel(h3(" PERFROMANCE IN MUSANZE DISTRICT")),
                #title = "Science Perfomance in all Districts",ddd
                shinyjs::useShinyjs(),
                tags$head(
                  #tags$link(href = "mystyle.css", rel = "stylesheet")
                ),
  div(tags$img( src = "Capture.PNG",width = 1600, height = 600)),
  #headerPanel(h3(" PERFROMANCE IN MUSANZE DISTRICT")),
  #title = "Science Perfomance in all Districts",
  shinyjs::useShinyjs(),
  tags$head(
   # tags$link(href = "mystyle.css", rel = "stylesheet")
  ),
                
                tabsetPanel(
                  tabPanel(
                    div(icon("bar-chart"),"Overall Perfomance"),
                    fluidRow(
                      
                      column(3,
                             wellPanel(
                               selectInput(inputId="District2",label = h3("District Name"),choices = c(c("All",unique(PERFORMANCE$District_name))),selected = "All"),
                               selectInput(inputId = "subject",
                                           label = h3("Subject"),
                                           choices = list("All" = "all", "Mathematics"="Mathematics",
                                                          "Physics" = "Physics", "Biology" = "Biology",
                                                          "Chemistry" = "Chemistry")
                               ),
                               radioButtons(inputId = "gender1",
                                            label = h3("Gender"),
                                            choices = list("All" = "all",  "Male"="Male", "Female"= "Female"),
                                            selected = "all"),
                               sliderInput(inputId = "years",
                                           label = h3("Years  to aggregate:"),
                                           min = 2013,
                                           max = 2017,
                                           value = c(2013,2017))#, step = 0.1
                             )
                      ),
                      
                      column(8,
                             plotOutput(outputId = "distPlot")
                      )
                    ),
                    
                    fluidRow(
                      
                      column(4,
                             plotOutput(outputId = "distPlot3")
                             
                      ),
                      
                      column(8,
                             plotOutput(outputId = "distPlot2")
                      )
                    )),
                  tabPanel(
                    div(icon("line-chart"),"Trends"),
                    sidebarLayout(
                      sidebarPanel(
                        selectInput(inputId = "District",label = h3("District Name"),choices = c(c("All",unique(PERFORMANCE$District_name))),selected = "All"),
                        selectInput(inputId = "subject2",
                                    label = h3("Subject"),
                                    choices = list("All" = "all", "Mathematics"="Mathematics",
                                                   "Physics" = "Physics", "Biology" = "Biology",
                                                   "Chemistry" = "Chemistry")
                        ),
                        radioButtons(inputId = "gender2",
                                     label = h3("Gender"),
                                     choices = list("All" = "all",  "Male"="Male", "Female"= "Female"),
                                     selected = "all"),
                        checkboxGroupInput("grades", label = h3("Grades"), 
                                           choices = list("1" = 1, "2" = 2, " 3" = 3, "4" = 4, "5"=5,"6"=6, "7"=7, "8"=8, "9" =9),
                                           selected = 1), width = 3
                      ),
                      
                      
                      # Show a plot of the generated distribution
                      mainPanel(
                        h4('Perfomance in Science in Districts from 2013-2017', align = "center"),
                        showOutput("plotter","nvd3")
                        
                      )
                    ))
                )
)
    # Define server logic required to draw a histogram
    server <- function(input, output) {
      output$plotter <- renderChart2({
        
        w <- input$District
        if(w=="All"){
        }else{
          PERFORMANCE <- PERFORMANCE %>% filter(District_name == w)
        }
       
        y <- input$subject2
        if(y=="all"){
        }else{
          PERFORMANCE <- PERFORMANCE %>% filter(Subject == y)
        }
       
        x <- input$gender2
        if(x=="all"){
        }else{
          PERFORMANCE <- PERFORMANCE %>% filter(Gender == x)
        }
        
       
        PERFORMANCE <- PERFORMANCE %>% filter(Grade %in% input$grades)
        
        
        if(input$gender2 == "all"){
          tit <- paste0("GRADE ",paste(input$grades,collapse = "&"), " TREND FOR BOTH BOYS AND GIRLS IN ", ifelse(input$subject2 == "all","ALL SUBJECTS",toupper(input$subject2)))
        }else if(input$gender2 == "Male"){
          tit <- paste0("BOYS' PERFOMANCE TREND IN ", ifelse(input$subject2 == "all","",toupper(input$subject2)))
        }else{
          tit <- paste0("GIRLS' PERFOMANCE TREND IN ", ifelse(input$subject2 == "all","",toupper(input$subject2)))
        }
        thing <- as_tibble(PERFORMANCE)  %>% group_by(Year, Gender) %>% summarize(freq = sum(Gender_count))
        p7 <-  nPlot(freq ~ Year, group = 'Gender', data = thing ,type = 'lineChart', width = 650)
        p7$set(xScale = 'ordinal', yScale = 'linear', title = tit)
        p7$chart(color = c('Green',  'Blue'))
        p7
        #print(p7)
      })
      
     
      datasetInput <- reactive({
        w <- input$District2
        if(w=="All"){
        }else{
          PERFORMANCE <- PERFORMANCE %>% filter(District_name == w)
        }
      
        y <- input$subject
        if(y=="all"){
        }else{
          PERFORMANCE <- PERFORMANCE %>% filter(Subject == y)
        } 
        x <- input$gender1
        if(x=="all"){
        }else{
          PERFORMANCE <- PERFORMANCE %>% filter(Gender ==x)
        }
        
        z <- input$years
        PERFORMANCE <- PERFORMANCE %>% filter(Year %in% seq(z[1],z[2],1))
        
       
      })
      
      output$distPlot2 <- renderPlot({
        dat1 <- datasetInput()
        if(input$gender1 == "all"){
          tit <- "PERFOMANCE SEPERATED BY SEX"
        }else if(input$gender1 == "Male"){
          tit <- paste0("BOYS' PERFOMANCE ", ifelse(input$subject == "all","",toupper(input$subject)))
        }else{
          tit <- paste0("GIRLS' PERFOMANCE ", ifelse(input$subject == "all","",toupper(input$subject)))
        }
        thing <- as_tibble(dat1)  %>% group_by(Grade, Gender) %>% summarize(freq = sum(Gender_count))
        thing <- thing %>%  mutate(percentage=`freq`/sum(`freq`))
        thing$percentage <- 100*thing$freq/sum(thing$freq)
        p <- ggplot(thing, aes(fill=Gender, y=percentage, x=factor(Grade))) + 
          geom_bar( stat="identity") + theme_minimal() +   scale_x_discrete( expand = c(0, 0)) +
          scale_y_continuous(expand = c(0, 0)) +scale_fill_manual(values=c("Green", "Blue")) +
          labs(x = "Grade",  title = tit)+
          theme(plot.title=element_text(family='', face='bold', colour='blue', size=15,hjust = 0.5))
        
        print(p)
      })
      
      #output$range <- renderPrint({ c(input$years[1],input$years[2]) })
      
      output$distPlot <- renderPlot({
        dat2 <- datasetInput()
        
        subject <- ifelse(length(unique(dat2$Subject))==1,toupper(unique(dat2$Subject)),"SCIENCES")
        sex <- ifelse(length(unique(dat2$Gender))==1,unique(dat2$Gender),"")
        District1 <- ifelse(length(unique(dat2$District_name))==1,unique(dat2$District_name),"ALL DISTICTS")
        if(sex == "Male"){
          sex <- "BOYS'"
        }else if(sex=="Female"){
          sex <- "GIRLS'"
        }
        thing <- as_tibble(dat2)  %>% group_by(Grade) %>% summarize(freq = sum(Gender_count))
        df <- thing %>%  mutate(propn=`freq`/sum(`freq`), Grade = factor(Grade))# %>% arrange(desc(Grade))
        df <- rbind(df[7:9,], df[1:6,])
        df <- df %>%   mutate(end = 2 * pi * cumsum(freq)/ sum(freq),
                              start = lag(end, default = 0),
                              middle = 0.5 * (start + end),
                              hjust = ifelse(middle > pi, 1, 0),
                              vjust = ifelse(middle < pi/2 | middle > 3 * pi/2, 0, 1))
        
        df$label <- scales::percent(df$propn)
        p <- ggplot(df) + 
          geom_arc_bar(aes(x0 = 0, y0 = 0, r0 = 0.50, r = 1,
                           start = start, end = end, fill = Grade)) +
          geom_text(aes(x = 1.01 * sin(middle), y = 1.002 * cos(middle), label = paste0(round(propn*100), "%"),
                        hjust = hjust, vjust = vjust), size = 4.5) +
          coord_fixed()  +
          theme_void()+ labs(x = NULL, y = NULL, title = paste0(sex, " PERFOMANCE IN ",subject," IN"," ",District1," " ,"(",input$years[1], "-", input$years[2],")"))+
          scale_x_continuous(limits = c(-1.5, 1.4),  # Adjust so labels are not cut off
                             name = "", breaks = NULL, labels = NULL) +
          scale_y_continuous(limits = c(-1, 1),      # Adjust so labels are not cut off
                             name = "", breaks = NULL, labels = NULL)+
          theme(plot.title=element_text(family='', face='bold', colour='red', size=17, hjust = 0.5))
        print(p)
      })
      
      output$distPlot3 <- renderPlot({
      
        
        #dat <- read_excel("C:/Users/Jeanette/Desktop/ALL EXCEL/R DOCUMENT/ANALSE.xlsx")    # choose columns to display
        df2 <- PERFORMANCE %>% filter(Subject == "Biology") %>% group_by(Gender) %>% summarize(freq = sum(Gender_count))
        df2 <- df2 %>%  mutate(propn=`freq`/sum(`freq`))
        
        p <-ggplot(df2, aes(x="", y=propn, fill=Gender)) + geom_bar(stat="identity", width=1, color = "black")+
          coord_polar("y") + geom_text(aes(label = paste0(round(propn*100,1), "%")), position = position_stack(vjust = 0.5))+ 
          scale_fill_manual(values=c("Green", "Blue"))+
          labs(x = NULL, y = NULL, title = "GENDER COMPOSITION")+ theme_classic() + theme(axis.line = element_blank(),
                                                                                          axis.text = element_blank(),
                                                                                          axis.ticks = element_blank(),
                                                                                          plot.title = element_text(hjust = 0.5, face = "bold", color = "blue", size = 15),
                                                                                          legend.title = element_text(hjust = 0.5, size = 15))
        print(p)
      })
      
    }
    
    # Run the application 
    shinyApp(ui = ui, server = server)
    